function [Iout]=DIPgausspf(varargin)
%DIPgausspf	- 2-D filtering using Gaussian masks - prefiltered (integrated) 
%   H = DIPGAUSSPF(I,SIGMA,DX,DY) filters the data in image I with the 2-D FIR
%   filter. The filtering is done using an appropriate mask for convolution.
%   The mask is generated from a 2-D Gaussian function with sigma equal to SIGMA
%
%   Different types of masks can be specified by parameters DX,DY:
%
%       DX   - number of diferentiations in x direction
%       DY   - number of diferentiations in y direction
%
%   Default: DX=0,DY=0.
%
%   Note: DX+DY must be less or equal to 2.
%         If higher order derivatives are needed than use:
%			 DIPgaussf	- Fourier domain - slow but most accurate
%         DIPgausss  - using simbolic solver - NEEDS SYMBOLIC TOOLBOX!
%
%
%   By default the size of the mask is [8*SIGMA,8*SIGMA]
%
%   Example
%   -------
%       I = double(imread('stap.tif'));
%       I2 = DIPgausspf(I,1,1,0);
%       imshow(I,[]), figure, imshow(I2,[])
%
%   Copyright 1999-2000 
%   The Laboratory for Measurement and Instrumentation
%   University of Twente, the Netherlands
%   All Rights Reserved.
%
%   Author:Zoran Zivkovic
%   Contact:Z.Zivkovic@el.utwente.nl
%   Date:29-12-00.
%
%   See also DIPGAUSS, DIPGAUSSS, DIPGAUSSF, DIPCONVOLVEC, FILTER2, FSPECIAL
[Iin,sigma,typein]=ParseInputs(varargin{:});

siz = [4*round(sigma) 4*round(sigma)]; 
rgt=-(2*siz(1)+1)/2:(2*siz(1)+1)/2;
%correction!!! sampling must be at position (0,0)!!!
rgt=rgt+rgt(length(rgt)/2);
rg=rgt(2:length(rgt));


%gaussian
if strcmp(typein,'normal')
   %kernel
 	n=2*siz(1)+1;
 	kernel=zeros(1,n);
 	c = 1.0/(sigma*sqrt(2));
 	for i=1:siz(1)+1
       hulp(i) = erf((i-1+0.5)*c)-erf((i-1-0.5)*c);
   end
 	accu = hulp(1);
   for i=2:siz(1)+1
      accu = accu+(2.0*hulp(i));
   end
   
	for i=1:siz(1)
 		kernel(siz(1)+1-i) = (hulp(i+1)/accu);
   	kernel(siz(1)+1+i) = (hulp(i+1)/accu);
	end
 	kernel(siz(1)+1) = (hulp(1)/accu);
   
   
   Iout=cconvolve(double(Iin),double(kernel'),4.0);%both directions !!!!important - matrices used in C coloumnwise
end

%gauss-dx
if strcmp(typein,'dx')
   %kernel dx 
  	c =  1.0/(sigma*sqrt(2.0*pi));
   sigma2=sigma^2;
 	n=2*siz(1)+1;
 	kernelx=zeros(1,n);

	for i=1:n
		x=i-siz(1)-1;
		x1 = x - 0.5;
		x2 = x + 0.5;
		kernelx(i)= c*(exp(-0.5*x2*x2/sigma2)-exp(-0.5*x1*x1/sigma2));
	end
   
   %kernel
 	kernel=zeros(1,n);
 	c = 1.0/(sigma*sqrt(2));
 	for i=1:siz(1)+1
       hulp(i) = erf((i-1+0.5)*c)-erf((i-1-0.5)*c);
   end
 	accu = hulp(1);
   for i=2:siz(1)+1
      accu = accu+(2.0*hulp(i));
   end
  	for i=1:siz(1)
 		kernel(siz(1)+1-i) = (hulp(i+1)/accu);
   	kernel(siz(1)+1+i) = (hulp(i+1)/accu);
	end
 	kernel(siz(1)+1) = (hulp(1)/accu);

   
   Iout=cconvolve(double(Iin),double(kernelx'),2.0);%xdirection !!!!important - matrices used in C coloumnwise
   Iout=cconvolve(double(Iout),double(kernel'),3.0);%ydirection !!!!important - matrices used in C coloumnwise
end

%gauss-dxdx
if strcmp(typein,'dxdx')
   %hx = ((rg.^2/(sqrt(2*pi)*sigma^5))-(1/(sqrt(2*pi)*sigma^3))).*exp(-(rg.*rg)/(2*sigma*sigma));
   %hy = (1/(sqrt(2*pi)*sigma)).*exp(-(rg.*rg)/(2*sigma*sigma));

   %kernel ddx 
   c =  1.0/(sigma^3*sqrt(2.0*pi));
   sigma2=sigma^2;
 	n=2*siz(1)+1;
 	kernelx=zeros(1,n);
    for i=1:n
		x=i-siz(1)-1;
		x1 = x - 0.5;
      x2 = x + 0.5;
      if (i==1)
         kernelxx(i)= c*(-x2*exp(-0.5*x2*x2/sigma2));
      else
         if (i==n)
            kernelxx(i)= c*(x1*exp(-0.5*x1*x1/sigma2));
         else
            kernelxx(i)= c*(x1*exp(-0.5*x1*x1/sigma2)-x2*exp(-0.5*x2*x2/sigma2));
         end
      end
   end
   %kernel
 	kernel=zeros(1,n);
 	c = 1.0/(sigma*sqrt(2));
 	for i=1:siz(1)+1
       hulp(i) = erf((i-1+0.5)*c)-erf((i-1-0.5)*c);
   end
 	accu = hulp(1);
   for i=2:siz(1)+1
      accu = accu+(2.0*hulp(i));
   end
  	for i=1:siz(1)
 		kernel(siz(1)+1-i) = (hulp(i+1)/accu);
   	kernel(siz(1)+1+i) = (hulp(i+1)/accu);
	end
 	kernel(siz(1)+1) = (hulp(1)/accu);

   
   Iout=cconvolve(double(Iin),double(kernelxx'),2.0);%xdirection !!!!important - matrices used in C coloumnwise
   Iout=cconvolve(double(Iout),double(kernel'),3.0);%ydirection !!!!important - matrices used in C coloumnwise
end

%gauss-dy
if strcmp(typein,'dy')
   %kernel dx 
  	c =  1.0/(sigma*sqrt(2.0*pi));
   sigma2=sigma^2;
 	n=2*siz(1)+1;
 	kernelx=zeros(1,n);

	for i=1:n
		x=i-siz(1)-1;
		x1 = x - 0.5;
		x2 = x + 0.5;
		kernelx(i)= c*(exp(-0.5*x2*x2/sigma2)-exp(-0.5*x1*x1/sigma2));
	end
   
   %kernel
 	kernel=zeros(1,n);
 	c = 1.0/(sigma*sqrt(2));
 	for i=1:siz(1)+1
       hulp(i) = erf((i-1+0.5)*c)-erf((i-1-0.5)*c);
   end
 	accu = hulp(1);
   for i=2:siz(1)+1
      accu = accu+(2.0*hulp(i));
   end
  	for i=1:siz(1)
 		kernel(siz(1)+1-i) = (hulp(i+1)/accu);
   	kernel(siz(1)+1+i) = (hulp(i+1)/accu);
	end
 	kernel(siz(1)+1) = (hulp(1)/accu);
    
   Iout=cconvolve(double(Iin),double(kernel'),2.0);%xdirection!!!!important - matrices used in C coloumnwise
   Iout=cconvolve(double(Iout),double(kernelx'),3.0);%ydirection !!!!important - matrices used in C coloumnwise
end

%gauss-dydy
if strcmp(typein,'dydy')
%kernel ddx 
   c =  1.0/(sigma^3*sqrt(2.0*pi));
   sigma2=sigma^2;
 	n=2*siz(1)+1;
 	kernelx=zeros(1,n);
	for i=1:n
		x=i-siz(1)-1;
		x1 = x - 0.5;
		x2 = x + 0.5;
      if (i==1)
         kernelxx(i)= c*(-x2*exp(-0.5*x2*x2/sigma2));
      else
         if (i==n)
            kernelxx(i)= c*(x1*exp(-0.5*x1*x1/sigma2));
         else
            kernelxx(i)= c*(x1*exp(-0.5*x1*x1/sigma2)-x2*exp(-0.5*x2*x2/sigma2));
         end
      end
	end
   %kernel
 	kernel=zeros(1,n);
 	c = 1.0/(sigma*sqrt(2));
 	for i=1:siz(1)+1
       hulp(i) = erf((i-1+0.5)*c)-erf((i-1-0.5)*c);
   end
 	accu = hulp(1);
   for i=2:siz(1)+1
      accu = accu+(2.0*hulp(i));
   end
  	for i=1:siz(1)
 		kernel(siz(1)+1-i) = (hulp(i+1)/accu);
   	kernel(siz(1)+1+i) = (hulp(i+1)/accu);
	end
   kernel(siz(1)+1) = (hulp(1)/accu);
   
	Iout=cconvolve(double(Iin),double(kernel'),2.0);%xdirection !!!!important - matrices used in C coloumnwise
   Iout=cconvolve(double(Iout),double(kernelxx'),3.0);%ydirection !!!!important - matrices used in C coloumnwise
end

%gauss-dxdy
if strcmp(typein,'dxdy')
 %kernel dx 
  	c =  1.0/(sigma*sqrt(2.0*pi));
   sigma2=sigma^2;
 	n=2*siz(1)+1;
 	kernelx=zeros(1,n);

	for i=1:n
		x=i-siz(1)-1;
		x1 = x - 0.5;
		x2 = x + 0.5;
		kernelx(i)= c*(exp(-0.5*x2*x2/sigma2)-exp(-0.5*x1*x1/sigma2));
   end
   
	Iout=cconvolve(double(Iin),double(kernelx'),4.0);%both directions !!!!important - matrices used in C coloumnwise
end


%----------------------------------------------------------------------
% Subfunction ParseInputs
%----------------------------------------------------------------------

function [Iin,Sigma,typein] =  ParseInputs(varargin);

error(nargchk(1,4,nargin));
%MSG = NARGCHK(LOW,HIGH,N) returns an appropriate error message if
%    N is not between low and high. If it is, return empty matrix.

Iin = varargin{1};

%defaults
typein = 'normal';
Sigma=2;

methods = {'normal','dx','dxdx';'dy','dxdy','err';'dydy','err','err'};
   
if nargin>1
   Sigma=varargin{2};%!!!! special braces to make it numerical
end
if nargin>2
	if nargin==4
   	i = varargin{3};
   	j = varargin{4};
      if ((j>2)|(i>2)|(j<0)|(i<0)|(round(i)~=i)|(round(j)~=j))
         typein='err';
      else
         typein = methods{j+1,i+1};
      end
      if strcmp(typein,'err')
         disp('DX+DY must be less or equal to 2.');
         disp('If higher order derivatives are needed than use:')
         disp('DIPgaussf  - Fourier domain - slow but most accurate')
      	disp('DIPgausss  - using simbolic solver - NEEDS SYMBOLIC TOOLBOX!')
      	error(['Invalid input string: ',num2str(varargin{3}),',',num2str(varargin{4}),'.']);
   	end
	else
      error(['If DX is specified DY must be specified!!!']);
   end
end

if Sigma<1
   disp('Warning: For small sigma it is more accurate to use DIPgaussf-Fourier domain!');
end

if Sigma<0
   error('Sigma must be positive');
end
