function [Iout]=DIPgauss(varargin)
%DIPgauss	- 2-D filtering using Gaussian masks - standard 
%   H = DIPGAUSS(I,SIGMA,DX,DY,S) filters the data in image I with the 2-D FIR
%   filter. The filtering is done using an appropriate mask for convolution.
%   The mask is generated from a 2-D Gaussian function with sigma equal to SIGMA
%
%   Different types of masks can be specified by parameters DX,DY:
%
%       DX   - number of diferentiations in x direction
%       DY   - number of diferentiations in y direction
%
%   Default: DX=0,DY=0.
%   Added:29-8-2003
%       SYX=SIGMAY/SIGMAX - unisutropic kernel
%   Default: S=1.0; 
%
%   Note: DX+DY must be less or equal to 2.
%         If higher order derivatives are needed than use:
%			 DIPgaussf	- Fourier domain - slow but most accurate
%         DIPgausss  - using simbolic solver - NEEDS SYMBOLIC TOOLBOX!
%
%
%   By default the size of the mask is [8*SIGMA,8*SIGMA]
%
%   Example
%   -------
%       I = double(imread('stap.tif'));
%       I2 = DIPgauss(I,2,1,0);
%       imshow(I,[]), figure, imshow(I2,[])
%
%   Copyright 1999-1999 
%   The Laboratory for Measurements and instrumentation
%   University of Twente, the Netherlands
%   All Rights Reserved.
%
%   Author:Zoran Zivkovic
%   Contact:Z.Zivkovic@el.utwente.nl
%   Date:7-12-99
%   Non-isotropic filtering added on 29-8-2003 by Zoran Zivkovic
%
%   See also DIPGAUSSS, DIPGAUSSF, DIPCONVOLVEC, CONV2, EDGE, FILTER2, FSPECIAL
[Iin,sigma,SYX,typein]=ParseInputs(varargin{:});

%siz = [8*round(sigma) 8*round(sigma)]; 
%rgt=-(siz(1)-1)/2:(siz(1)-1)/2;
%correction!!! sampling must be at position (0,0)!!!
%rgt=rgt+rgt(length(rgt)/2);
%rg=rgt(2:length(rgt));

%new
if (length(sigma)==2)
    %anisotropic
    Iout=Iin;
    if (sigma(1)>0.5)
        %X direction
        siz=round(3*sigma(1));
        rg=-siz:siz;
        hx = (1/(sqrt(2*pi)*sigma(1))).*exp(-(rg.*rg)/(2*sigma(1)*sigma(1)));
        hx=hx/sum(hx);
        Iout=cconvolve(double(Iout),double(hx'),2.0);%xdirection !!!!important - matrices used in C coloumnwise
    end
    if (sigma(2)>0.5)
        %Y direction
        siz=round(3*sigma(2));
        rg=-siz:siz;
        hy = (1/(sqrt(2*pi)*sigma(2))).*exp(-(rg.*rg)/(2*sigma(2)*sigma(2)));
        hy=hy/sum(hy);
        Iout=cconvolve(double(Iout),double(hy'),3.0);%ydirection !!!!important - matrices used in C coloumnwise
    end
else
    
    siz=round(3*sigma);
    rg=-siz:siz;

%gaussian
if strcmp(typein,'normal') 
    if (SYX==1)
        h = (1/(sqrt(2*pi)*sigma)).*exp(-(rg.*rg)/(2*sigma*sigma));
        h=h/sum(h);
        Iout=cconvolve(double(Iin),double(h'),4.0);%both directions !!!!important - matrices used in C coloumnwise
    else
        hx = (1/(sqrt(2*pi)*sigma)).*exp(-(rg.*rg)/(2*sigma*sigma));
        %Y direction
        sigma=sigma*SYX;%sigmaY
        %siz=[round(siz(1)*SYX) round(siz(2)*SYX)];
        %rgt=-(siz(1)-1)/2:(siz(1)-1)/2;
        %correction!!! sampling must be at position (0,0)!!!
        %rgt=rgt+rgt(length(rgt)/2);
        %rg=rgt(2:length(rgt));
        siz=round(4*sigma);
        rg=-siz:siz;
        hy = (1/(sqrt(2*pi)*sigma)).*exp(-(rg.*rg)/(2*sigma*sigma));
        Iout=cconvolve(double(Iin),double(hx'),2.0);%xdirection !!!!important - matrices used in C coloumnwise
        Iout=cconvolve(double(Iout),double(hy'),3.0);%ydirection !!!!important - matrices used in C coloumnwise
    end
end

%gauss-dx
if strcmp(typein,'dx')
   hx = -(rg/(sqrt(2*pi)*sigma^3)).*exp(-(rg.*rg)/(2*sigma*sigma));
   hy = (1/(sqrt(2*pi)*sigma)).*exp(-(rg.*rg)/(2*sigma*sigma));
   Iout=cconvolve(double(Iin),double(hx'),2.0);%xdirection !!!!important - matrices used in C coloumnwise
   Iout=cconvolve(double(Iout),double(hy'),3.0);%ydirection !!!!important - matrices used in C coloumnwise
end

%gauss-dxdx
if strcmp(typein,'dxdx')
   hx = ((rg.^2/(sqrt(2*pi)*sigma^5))-(1/(sqrt(2*pi)*sigma^3))).*exp(-(rg.*rg)/(2*sigma*sigma));
   hy = (1/(sqrt(2*pi)*sigma)).*exp(-(rg.*rg)/(2*sigma*sigma));
	Iout=cconvolve(double(Iin),double(hx'),2.0);%xdirection !!!!important - matrices used in C coloumnwise
   Iout=cconvolve(double(Iout),double(hy'),3.0);%ydirection !!!!important - matrices used in C coloumnwise
end

%gauss-dy
if strcmp(typein,'dy')
   hy = -(rg/(sqrt(2*pi)*sigma^3)).*exp(-(rg.*rg)/(2*sigma*sigma));
   hx = (1/(sqrt(2*pi)*sigma)).*exp(-(rg.*rg)/(2*sigma*sigma));
   Iout=cconvolve(double(Iin),double(hx'),2.0);%xdirection!!!!important - matrices used in C coloumnwise
   Iout=cconvolve(double(Iout),double(hy'),3.0);%ydirection !!!!important - matrices used in C coloumnwise
end

%gauss-dydy
if strcmp(typein,'dydy')
   hy = ((rg.^2/(sqrt(2*pi)*sigma^5))-(1/(sqrt(2*pi)*sigma^3))).*exp(-(rg.*rg)/(2*sigma*sigma));
   hx = (1/(sqrt(2*pi)*sigma)).*exp(-(rg.*rg)/(2*sigma*sigma));
	Iout=cconvolve(double(Iin),double(hx'),2.0);%xdirection !!!!important - matrices used in C coloumnwise
   Iout=cconvolve(double(Iout),double(hy'),3.0);%ydirection !!!!important - matrices used in C coloumnwise
end

%gauss-dxdy
if strcmp(typein,'dxdy')
   h = -(rg/(sqrt(2*pi)*sigma^3)).*exp(-(rg.*rg)/(2*sigma*sigma));
	Iout=cconvolve(double(Iin),double(h'),4.0);%both directions !!!!important - matrices used in C coloumnwise
end

end%new

%----------------------------------------------------------------------
% Subfunction ParseInputs
%----------------------------------------------------------------------

function [Iin,Sigma,SYX,typein] =  ParseInputs(varargin);

error(nargchk(1,5,nargin));
%MSG = NARGCHK(LOW,HIGH,N) returns an appropriate error message if
%    N is not between low and high. If it is, return empty matrix.

Iin = varargin{1};

%defaults
typein = 'normal';
Sigma=2;
SYX=1;

methods = {'normal','dx','dxdx';'dy','dxdy','err';'dydy','err','err'};
   
if nargin>1
   Sigma=varargin{2};%!!!! special braces to make it numerical
end
if nargin>2
	if nargin>3
   	    i = varargin{3};
   	    j = varargin{4};
        if ((j>2)|(i>2)|(j<0)|(i<0)|(round(i)~=i)|(round(j)~=j))
            typein='err';
        else
            typein = methods{j+1,i+1};
        end
        if strcmp(typein,'err')
         disp('DX+DY must be less or equal to 2.');
         disp('If higher order derivatives are needed than use:')
         disp('DIPgaussf  - Fourier domain - slow but most accurate')
      	disp('DIPgausss  - using simbolic solver - NEEDS SYMBOLIC TOOLBOX!')
      	error(['Invalid input string: ',num2str(varargin{3}),',',num2str(varargin{4}),'.']);
   	    end
	else
      error(['If DX is specified DY must be specified!!!']);
   end
end

if nargin==5
   	SYX = varargin{5};
end

if SYX<0
   error('Ratio SigmaY/SigmaX must be positive');
end

if (Sigma<1)|(Sigma*SYX<1)
   %disp('Warning: For small sigma it is more accurate to use DIPgaussf-Fourier domain!');
end

if Sigma<0
   error('Sigma must be positive');
end
