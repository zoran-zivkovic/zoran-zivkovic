function [Iout]=DIPgausss(Iin,sigma,dx,dy)
%DIPgausss	- 2-D filtering using Gaussian masks - symbolic 
%   H = DIPGAUSS(I,SIGMA,DX,DY) filters the data in image I with the 2-D FIR
%   filter. The filtering is done using an appropriate mask for convolution.
%   The mask is generated from a 2-D Gaussian function with sigma equal to SIGMA
%
%   Different types of masks can be specified by parameters DX,DY:
%
%       DX   - number of diferentiations in x direction
%       DY   - number of diferentiations in y direction
%
%   Note: NEEDS SYMBOLIC TOOLBOX!
%         Look also at:
%      	 DIPgaussf	- Fourier domain - slow but most accurate
%         DIPgauss   - DX+DY<3 
%
%
%   By default the size of the mask is [8*SIGMA,8*SIGMA]
%
%   Example
%   -------
%       I = double(imread('stap.tif'));
%       I2 = DIPgausss(I,2,5,7);
%       imshow(I,[]), figure, imshow(I2,[])
%
%   Copyright 1999-1999 
%   The Laboratory for Measurements and instrumentation
%   University of Twente, the Netherlands
%   All Rights Reserved.
%
%   Author:Zoran Zivkovic
%   Contact:Z.Zivkovic@el.utwente.nl
%   Date:8-12-99
%
%   See also DIPGAUSS, DIPGAUSSF, DIPCONVOLVEC, CONV2, EDGE, FILTER2, FSPECIAL

siz = [8*round(sigma) 8*round(sigma)]; 
rgt=-(siz(1)-1)/2:(siz(1)-1)/2;
%correction!!! sampling must be at position (0,0)!!!
rgt=rgt+rgt(length(rgt)/2);
rg=rgt(2:length(rgt));

%symbolic toolbox
syms x y
hxs=diff(1/(sqrt(2*pi)*sigma)*exp(-x^2/(2*sigma^2)),'x',dx);
hys=diff(1/(sqrt(2*pi)*sigma)*exp(-y^2/(2*sigma^2)),'y',dy);


for i=1:siz(1)-1
   x=rg(i);
   y=rg(i);
   hx(i) =eval(hxs);
   hy(i) =eval(hys);
end

Iout=cconvolve(double(Iin),double(hx'),2.0);%xdirection
Iout=cconvolve(double(Iout),double(hy'),3.0);%ydirection
