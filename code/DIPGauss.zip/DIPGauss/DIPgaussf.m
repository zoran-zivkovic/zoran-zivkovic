function [Iout]=DIPgaussf(varargin)
%DIPgausssf	- 2-D filtering using Gaussian masks - Fourier domain 
%   H = DIPGAUSS(I,SIGMA,DX,DY) filters the data in image I with the 2-D FIR
%   filter. The filtering is done using an appropriate mask for convolution.
%   The mask is generated from a 2-D Gaussian function with sigma equal to SIGMA
%
%   Different types of masks can be specified by parameters DX,DY:
%
%       DX   - number of diferentiations in x direction
%       DY   - number of diferentiations in y direction
%
%   Note: Fourier domain - slow but most accurate
%         Look also at:
%      	 DIPgausss	- symbolic evaluation - NEEDS SYMBOLIC TOOLBOX!
%         DIPgauss   - DX+DY<3 
%
%   Warning: The return value is complex array!
%
%   By default the size of the mask is [8*SIGMA,8*SIGMA]
%
%   Example
%   -------
%       I = double(imread('zon.tif'));
%       I2 = real(DIPgaussf(I,2,5,13));%Real part of complex array!
%       imshow(I,[]), figure, imshow(I2,[])
%
%   Copyright 1999-1999 
%   The Laboratory for Measurements and instrumentation
%   University of Twente, the Netherlands
%   All Rights Reserved.
%
%   Author:Zoran Zivkovic
%   Contact:Z.Zivkovic@el.utwente.nl
%   Date:07-03-00
%
%   See also DIPGAUSS, DIPGAUSSS, DIPCONVOLVEC, CONV2, EDGE, FILTER2, FSPECIAL
[Iin,sigma,dx,dy] =  ParseInputs(varargin{:});
Iinsize=size(Iin);
temp=0:-2*pi/Iinsize(1):-pi;
Fgridy=[temp(length(temp):-1:2) 0:2*pi/Iinsize(1):pi];
temp=0:-2*pi/Iinsize(2):-pi;
Fgridx=[temp(length(temp):-1:2) 0:2*pi/Iinsize(2):pi];

[w,v]=meshgrid(Fgridx(1:Iinsize(2)),Fgridy(1:Iinsize(1)));
% the phase of this kernel is as it begins with 1,1 in the image plane!!!
Gxy=((-sqrt(-1)*w).^dx).*((-sqrt(-1)*v).^dy).*exp(-0.5*sigma^2*(w.^2+v.^2));

%CORRECTION!!!
if (Iinsize(1)/2==round(Iinsize(1)/2))%even
   if ((dy/2)~=round(dy/2))%odd
      Gxy(1,:)=zeros(1,Iinsize(2));
   end
end
if (Iinsize(2)/2==round(Iinsize(2)/2))%even
   if ((dx/2)~=round(dx/2))%odd
      Gxy(:,1)=zeros(Iinsize(1),1);
   end
end


%figure(1)
%if (dx==dy==sigma==0.0)
%	imshow(abs(Gxy),[]);pixval
%else
%  imshow(abs(Gxy),[]);pixval
%end
%figure(2)
%imshow(fftshift(ifft2(fftshift(Gxy))),[]);
%imshow(log(abs(fftshift(fft2(Iin)))),[]);pixval
Iout=real(ifft2(ifftshift(Gxy).*fft2(double(Iin))));
%Iout=ifft2(fftshift((Gxy).*fftshift(fft2(Iin))));
%size(Iout);
%imshow(abs(Iout),[]);

%----------------------------------------------------------------------
% Subfunction ParseInputs
%----------------------------------------------------------------------

function [Iin,Sigma,dx,dy] =  ParseInputs(varargin);

error(nargchk(1,4,nargin));
%MSG = NARGCHK(LOW,HIGH,N) returns an appropriate error message if
%    N is not between low and high. If it is, return empty matrix.

Iin = varargin{1};

%defaults
Sigma=2;
dx=0;
dy=0;

if nargin>1
   Sigma=varargin{2};%!!!! special braces to make it numerical
end
if nargin>2
	if nargin==4
   	dx = varargin{3};
   	dy = varargin{4};
	else
      error(['If DX is specified DY must be specified!!!']);
   end
end


if Sigma<0
   error('Sigma must be positive');
end
