function [Out]=DIPconvolvec(varargin)
%DIPconvolvec - image convolution with a kernel
%   [Out]=DIPconvolvec(In,Kernel,Type) - performs convolution with the kernel 
%   Kernel on the image In, according to Type.
%
%			TYPE:
%			NO ARGUMENT - standard convolution
%			x           - 1 dimensional x-direction
%			y           - 1 dimensional y-direction
%			xy          - both directions
%
%   This is only a mask for underlying C-function cconvolve.dll.
%
%   Warning: for one dimensional convolution Kernel must be a row vector.
%
%   Example
%   -------
%       I = double(imread('zon.tif'));
%       I2 = DIPconvolvec(I,[-1 1],'x');
%       imshow(I,[]), figure, imshow(I2,[])
%
%
%   Copyright 1999-1999 
%   The Laboratory for Measurements and instrumentation
%   University of Twente, the Netherlands
%   All Rights Reserved.
%
%   Author:Zoran Zivkovic 	
%   Contact:Z.Zivkovic@el.utwente.nl
%   Date:7-12-99
%
%   See also DIPGAUSS,DIPGAUSSS,DIPEDGE.

[In,Kernel,Type]=ParseInputs(varargin{:});

Out=cconvolve(double(In),double(Kernel'),double(Type));

%----------------------------------------------------------------------
% Subfunction ParseInputs
%----------------------------------------------------------------------

function [In,Kernel,Type] =  ParseInputs(varargin);

error(nargchk(2,3,nargin));
%MSG = NARGCHK(LOW,HIGH,N) returns an appropriate error message if
%    N is not between low and high. If it is, return empty matrix.

In = varargin{1};
Kernel = varargin{2};

%defaults
Type = 1;

methods = {'x','y','xy'};
   
if nargin>2
   j = strmatch(varargin(3),methods);
   if ~isempty(j)
   	Type = j+1;
   else
      error(['Invalid input string: ''' varargin{3} '''.']);
   end
end

if (Type>1)
   siz=size(Kernel);
   if (siz(1)>siz(2))
      disp(' Warning: for one dimensional convolution Kernel must be a row vector.');
   end
end

