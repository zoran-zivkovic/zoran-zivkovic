function [nModesUsed]=demoGM1(nDataSet)
%[nModesUsed] = demoGM1(nDataSet)
% Recursive Unsupervised Learning of Finite Mixture Models
%
% Input:
% nDataSet - select a data set:  
%           1 - 'Three Gaussians'
%           2 - 'Iris'
%           3 - 'Shrinking Spiral'
%           4 - 'Enzyme'
%
% Output:
% nModesUsed - number of modes used at the end
%
% Note: the graph is updated after every 30 samples  
%
% Author:   Z.Zivkovic
% Date:     10-2-2003

if (nargin==0)
    help demoGM1
    break;
end

%data
R=[];%assume no mapping
switch nDataSet
case 1
    dataSet1;
    disp('Three Gaussians data set')
    nModes = 30;
    fAlpha=1/150;
    %break;
case 2
    dataSet2;
    disp('Iris data set')
    nModes = 20;
    fAlpha=1/150;
    %break;
case 3
    dataSet3;
    disp('Shrinking Spiral data set')
    nModes = 40;
    fAlpha=-log(0.05)/900;
    %break;
case 4
    dataSet4;
    disp('Enzyme data set')
    nModes = 10;
    fAlpha=-log(0.05)/245;
    %break;
end
%=>dataEM and R(optional)
nData=size(dataEM,2);

%parameters
%nModes - initial number of components
%fAlpha

%prepare for plotting
h=figure;set(h,'Double','on')%Double buffer for smooth display 
nHistory=round(1/fAlpha);%number of samples to plot
PlotData(dataEM(:,1:nHistory),R);
V=axis;
hold on

%starting algorithm
fprintf('Alpha: %1.5f, Initial nModes: %d \n',fAlpha,nModes);
%random initialization
[mixEM,meansEM,varsEM]=EMRandomInit(dataEM,nModes); 
disp('Starting ...')

bPlot=1;
tic
for iData=1:nData
    %%%%%%%%%%%%
    %plot
    if ((bPlot)&(mod(iData,30)==0))
        %update every 30-th frame
        clf
        if iData>nHistory
            %update data
            PlotData(dataEM(:,iData-nHistory:iData),R);
        else
            PlotData(dataEM(:,1:nHistory),R);
        end
        hold on
        %plot the estimate
        PlotGM(mixEM,meansEM,varsEM,2*fAlpha,100,R);
        %fix axis!
        axis(V)
        sTitle=sprintf('Estimate after %6d samples (showing last %d samples)',iData,nHistory);
        title(sTitle);
        drawnow;
    end
    %plot
    %%%%%%%%%%%
    
    %%%%%%%%%%%%%%%%%%%%%%%
    %algorithm - update step
    %input:dataNew,mixEM,meansEM,varsEM
    [mixEM,meansEM,varsEM]=EMStep(mixEM,meansEM,varsEM,dataEM(:,iData),fAlpha);
    %output: mixEM,meansEM,varsEM
    %algorithm - update step
    %%%%%%%%%%%%%%%%%%%%%%%
end
toc

%Sort
nModesUsed=length(find(mixEM));
[dummy,I]=sort(-mixEM);
mixEM=mixEM(I(1:nModesUsed));%decreasing
meansEM=meansEM(:,I(1:nModesUsed));
varsEM=varsEM(:,:,I(1:nModesUsed));
