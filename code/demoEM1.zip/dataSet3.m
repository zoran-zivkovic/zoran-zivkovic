nD=3;
nData=20*900;
dataEM=zeros(nD,nData);
iData=0;
for iData=1:nData
    %iMode
    t=4*pi*rand(1,1);
    n=1*randn(3,1);
    dataEM(:,iData)=[(13-0.5*t)*cos(t)+n(1);-(13-0.5*t)*sin(t)+n(2);t+n(3)];
end