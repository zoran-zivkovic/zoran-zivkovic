dataEM=load('enzymedata.txt');
nData=size(dataEM,1)*size(dataEM,2);
nD=1;
dataEM0=reshape(dataEM,nD,nData);

nRealizations=30;
dataEM=[];
for iR=1:nRealizations
    dataEM=[dataEM dataEM0(:,randperm(nData))];
end