dataEM=load('irisdata.txt');
if (size(dataEM,2)~=length(dataEM))
    dataEM=dataEM';
end

dataEM0=dataEM;
nData=size(dataEM,2);

nRealizations=35;
dataEM=[];
for iR=1:nRealizations
    dataEM=[dataEM dataEM0(:,randperm(nData))];
end

%mapping
matCov=cov(dataEM0');
[F,Lambda]=eig(matCov); %not sorted !!!!
%two largest components
[dummy,I]=sort(-diag(Lambda));
R=[F(:,I(1)) F(:,I(2))];

%return;
%plot the classes
if (0)
    data2D=R'*dataEM0;
    %classes
    figure
    plot(data2D(1,1:50),data2D(2,1:50),'x',data2D(1,51:100),data2D(2,51:100),'^',data2D(1,101:150),data2D(2,101:150),'o');
end
