nModes=3;
nD=2;
mixEM=ones(1,nModes)/nModes;
meansEM=[0 -2;0 0; 0 2]';
varsEM=zeros(nD,nD,nModes);
nData=5*900;
dataEM=zeros(nD,nData);
iData=0;
for iMode=1:nModes
    varsEM(:,:,iMode)=[2 0; 0 0.2];
end

for iData=1:nData
    %iMode
    rnum=rand(1,1);
    accmix=0;
    for iMode=1:nModes
        accmix=accmix+mixEM(iMode);
        if (rnum<accmix)
            break;
        end
    end
    %data
    [F,Lambda]=eig(varsEM(:,:,iMode));
    dataEM(:,iData)=meansEM(:,iMode)+F*Lambda^0.5*[randn(2,1)];
end
