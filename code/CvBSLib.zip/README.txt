This work may not be copied or reproduced 
in whole or in part for any commercial purpose. 
Permission to copy in whole or in part without payment of fee is granted 
for nonprofit educational and research purposes provided that all such
whole or partial copies include the following: 
-this notice; 
-an acknowledgment of the authors and individual 
contributions to the work; 
Copying, reproduction, or republishing for any other purpose 
shall require a license. Please contact the author in such cases.
All the code is provided without any guarantee.

Author: Zoran Zivkovic, www.zoranz.net